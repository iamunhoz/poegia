﻿Super [Mario] Script 2 Demo v1.1

This font was originally updated from Hey Gorgeous by FontAddict, adding some
much-needed glyphs for important characters in ASCII and Latin-1. However, it
still lacked a few ASCII characters such as the Grave (`), Curly Brackets
({, }), and the Vertical Line (|). In this updated version, the only missing
ASCII character glyph is the one for the Number Sign (#).

I interrupted work on this font because I am not willing to use an old version
of FontForge anymore; FontForge frequently crashes and corrupts my work, so I
must make frequent backups. I added some new characters with low effort, though:

U+00__
« (left guillemet for use in Romance languages other than Español)
» (right guillemet for use in Romance languages other than Español)

U+01__
Ĳ (Digraph of IJ from Nederlands)
ĳ (Digraph of ij from Nederlands)
ĸ ("Kra" from Nunatsiavummiutut, Old Greenlandic)

U+03__
Γ (Gamma from Greek)

U+1E__
Ẁ (W with grave from Welsh)
ẁ (w with grave)
Ẃ (W with acute from Welsh)
ẃ (w with acute)
Ẅ (W with diæresis from Welsh)
ẅ (w with diæresis)
Ẽ (E with tilde from Guaraní)
ẽ (e with tilde)
Ỳ (Y with acute)
ỳ (y with acute)
Ỹ (Y with tilde from Guaraní)
ỹ (y with tilde)

U+22__
∽ (reverse tilde, conveniently available because of wrongly-reversed tilde
   over Ã, Ñ, Õ, etc.)

This font is backwards-compatible with Hey Gorgeous and the original 1.001
version of Super [Mario] Script 2 Demo; change any project using Hey Gorgeous
to instead use Super [Mario] Script 2 Demo to make it work right away.
If you are already using Super [Mario] Script 2 Demo in your project, you do not
need to do anything.